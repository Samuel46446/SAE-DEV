class Card
{
    String str;
    int point;
}