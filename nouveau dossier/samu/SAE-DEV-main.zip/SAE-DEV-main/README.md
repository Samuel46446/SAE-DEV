# SAE-DEV

dir adam, samuel sont vides.

les commits à faire sont à faire dans le nom de son dossier pour éviter de foutre le bordel entre le code qui marche et celui qui pose problème.

ArchiveExemple/Shots est vide.
Archive/src sont les fonction disponible.
Archive/unused sont les fonction non-utilisées mais utiles pour les futures updates/upgrades.

(les dir vides ont des placeholder, mais sont quand même vide pour l'instant)
