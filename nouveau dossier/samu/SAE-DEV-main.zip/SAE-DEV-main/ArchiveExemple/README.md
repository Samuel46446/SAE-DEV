<Luigou Jackou>
===========

Développé par <Adam Stievenard> <Samuel Turp>
Contacts : <mail1> , <mail2>

# Présentation de <le nom de votre jeu>

<Description de votre jeu>
Des captures d'écran illustrant le fonctionnement du logiciel sont proposées dans le répertoire shots.


# Utilisation de <le nom de votre jeu>

Afin d'utiliser le projet, il suffit de taper les commandes suivantes dans un terminal :

```
./compile.sh
```
Permet la compilation des fichiers présents dans 'src' et création des fichiers '.class' dans 'classes'

```
./run.sh
```
Permet le lancement du jeu
