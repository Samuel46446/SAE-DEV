class Joueur
{
    Card[] tabCard = new Card[4];
    int nbEtoile = 30;
}