class Joueur
{
    Card ca1;
    Card ca2;
    Card ca3;
    Card ca4;
    int nbEtoile;
}